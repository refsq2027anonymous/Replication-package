# Replication package: Requirements Mutants (REFSQ 2027 research preview)

## Contents
- `tasks/T*/`, one folder per task:
  - `requirements.md`: the complete specification;
  - `requirements_gapped.md`: the requirements mutants;
  - `reference.py`: the intent reference;
  - `test_acceptance.py`: intent probes, each tagged `@pytest.mark.req("Rk")`.

  There are 55 probes, with at least one for every requirement.
- `tasks/gaps.json`: the nine seeded gaps.
- `harness.py`: pytest runner, branch coverage, and an AST mutation engine.
- `run_pilot.py`: agent loops (conditions A and S), spec-first suites (B), evaluation, the assertion pre-labeller and the assumption-surfacing judge. The model backend is pluggable through `call_batch`.
- `PROMPTS.md`: prompts, tool schemas and parameters, restated from `run_pilot.py`.
- `traces/exp1_fully_specified.json`: 30 control runs. Every round's code and tests, spec-first tests, evaluations and pre-labels.
- `traces/exp2_gapped.json`: 60 agent-loop runs (A, S) and 30 spec-first suites, with code, tests and assumptions for every round, evaluations and judge output.
- `results/`:
  - `summary.json`: all numbers reported in the paper;
  - `control_runs.csv`, `gapped_per_gap.csv`, `gapped_per_run.csv`, `gapped_specfirst.csv`;
  - `assertion_labels_for_review.csv`: model pre-labels, with empty columns for human labels.
- `superseded_first_run/`: traces of the first run. It was evaluated with a reference that used Python's `round()` and with three requirements that had no probe. The paper reports the second run only.

## Environment
Python 3.11, pytest 9.2.0, coverage 7.17.1. Agents: `claude-sonnet-5` and `claude-haiku-5-5`. Model outputs are not deterministic.

## Reproducing the evaluation
For each run in `traces/`, take the final round's `code` and `tests` and call `run_pilot.evaluate(task, code, tests)`. This recomputes intent match per requirement, the per-test status (consistent, lock-in = `drift_candidate`, defect-detecting, broken), branch coverage and mutation score. A new generation run needs a `call_batch` backend; see the module docstring.

## Notes
- Rounding requirements are meant as commercial rounding, with halves rounded up. This intent was fixed after the first run (see the paper's threats to validity).
- The shipping task's rounding probe cannot discriminate, because every intended fee is an exact amount.
- The LLM instruments (pre-labeller and surfacing judge) were not validated by humans.
- Tasks, references and mutants were created with LLM assistance and reviewed by the authors.

## Licence
Code (`*.py`): MIT. Data and documents (tasks, traces, results, Markdown files): CC BY 4.0. See `LICENSE.md`.
