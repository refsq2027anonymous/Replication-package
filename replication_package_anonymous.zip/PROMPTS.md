# Prompts, tool schemas and loop parameters

The authoritative source is `run_pilot.py`, which contains these prompts and tool schemas verbatim and implements the loop. This file restates them for reading.

## Models and parameters
- Agents: `claude-sonnet-5` ("larger") and `claude-haiku-5-5` ("smaller"), called via the vendor API.
- `max_tokens` 8000 per agent call. Temperature: the model default; it cannot be set for these models, so runs are not deterministic.
- Tool use is forced (`tool_choice` = the named tool).
- At most 4 rounds per agent-loop run (`MAX_ROUNDS = 4` in harness.py).
- Annotator and judge model: `claude-sonnet-5`.

## System prompt (all agent calls)
```
You are an autonomous coding agent working in a Python repository. Use the provided tool to write files.
```

## Condition A, initial user message
```
Implement the following in `solution.py` and write a pytest test suite `test_solution.py` that thoroughly tests your implementation.

{requirements}
```

## Condition S, initial user message
Same as condition A, followed by:
```


Where the requirements are ambiguous or incomplete, make a reasonable decision and list every assumption you made.
```

## Feedback message after a failing round (conditions A and S)
The message is sent as a tool result. The final phrase is "write both files again." in experiment 1 and "write all fields again." in experiment 2.
```
Files written. Running `pytest`:
```
{last 4000 characters of pytest stdout}
```
Some tests fail. Fix the problem so that the full test suite passes, and write both files again.
```

## Condition B (spec-first), single user message
```
Another developer is implementing the following in `solution.py`; you cannot see the implementation. Write a pytest test suite `test_solution.py` that thoroughly tests it against these requirements.

{requirements}
```

## Tool schemas
- `write_files` (conditions A and S). Required fields:
  - `solution_py` (string): "Full contents of solution.py".
  - `test_solution_py` (string): "Full contents of the pytest test file; import from solution".
  - Condition S only, `assumptions` (array of strings): "Every assumption you made where the requirements are ambiguous or incomplete".
- `write_tests` (condition B). Required field: `test_solution_py` (string).

## Assertion pre-labeller (experiment 1; instrument only, not human-validated)
Tool `label_assertions` returns, per assertion:
- `test` and `assertion`;
- `label`, one of anchored / contradicts / unanchored;
- `req_ids`;
- `rationale`.

Prompt:
```
You are annotating a test suite for a requirements-engineering study. You see ONLY the requirements and the tests (not the implementation).
For EVERY assertion (each `assert` statement and each `pytest.raises` check; for parametrized tests, each parameter case counts as one assertion) give:
- label "anchored": the checked behaviour and expected value follow from one or more requirements and are consistent with them;
- label "contradicts": the expected value or behaviour contradicts what the requirements say;
- label "unanchored": the requirements do not determine this behaviour (e.g. inputs or outputs they do not discuss); the test encodes an extra assumption.
Give the requirement ids involved (empty for unanchored) and a one-sentence rationale. Compute expected values yourself from the requirements before deciding.

REQUIREMENTS
{requirements}

TESTS
```python
{tests}
```
```

## Assumption-surfacing judge (experiment 2, condition S; instrument only, not human-validated, lenient)
```
For each requirement gap below, decide whether the developer's list of assumptions explicitly addresses that specific ambiguity (states a decision on it). Quote the matching assumption as evidence, or '' if none.

GAPS:
{gap id}: {gap description from tasks/gaps.json}
...

ASSUMPTIONS:
- {assumption}
...
```

## Loop logic
For each run:
1. Send the initial message.
2. Write `solution.py` and `test_solution.py` from the tool call.
3. Run pytest (harness.run_suite).
4. If every test passes, stop. Otherwise append the assistant tool call and the feedback message, and repeat, for at most 4 rounds.

The final round's code and tests are then evaluated:
- intent probes (`tasks/*/test_acceptance.py`) on the agent's code;
- the agent's suite on the agent's code and on the reference implementation, giving per-test status consistent / lock-in (drift_candidate) / defect-detecting / broken;
- branch coverage (coverage.py) and mutation score (harness.mutation_score) of the agent's suite on the agent's code.
