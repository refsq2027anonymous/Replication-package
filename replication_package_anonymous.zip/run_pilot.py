"""Pilot driver: agent loops (conditions A, S), spec-first tests (B), evaluation,
assertion pre-labelling and assumption-surfacing judgement.

The model backend is pluggable: `call_batch(requests)` takes a list of dicts
{model, system, messages, tool, max_tokens} and returns, per request, either the
tool-call input (dict) or {"error": str}. Requests are independent; run them
concurrently if the backend allows.
"""
import json, os, re, copy, statistics
from collections import Counter
import harness as H

BASE = os.path.dirname(os.path.abspath(__file__))
TASKS = ["T1_shipping", "T2_password", "T3_latefee", "T4_booking", "T5_grade"]
GAPS = json.load(open(os.path.join(BASE, "tasks", "gaps.json")))
REPS = 3

SYSTEM = "You are an autonomous coding agent working in a Python repository. Use the provided tool to write files."
PROMPT_A = ("Implement the following in `solution.py` and write a pytest test suite `test_solution.py` "
            "that thoroughly tests your implementation.\n\n{req}")
PROMPT_S = PROMPT_A + ("\n\nWhere the requirements are ambiguous or incomplete, make a reasonable decision "
                       "and list every assumption you made.")
PROMPT_B = ("Another developer is implementing the following in `solution.py`; you cannot see the implementation. "
            "Write a pytest test suite `test_solution.py` that thoroughly tests it against these requirements.\n\n{req}")
FEEDBACK = ("Files written. Running `pytest`:\n```\n{out}\n```\nSome tests fail. "
            "Fix the problem so that the full test suite passes, and write {what} again.")

TOOL_A = {"name": "write_files", "description": "Write the implementation and its pytest test suite.",
          "input_schema": {"type": "object", "properties": {
              "solution_py": {"type": "string", "description": "Full contents of solution.py"},
              "test_solution_py": {"type": "string", "description": "Full contents of the pytest test file; import from solution"}},
              "required": ["solution_py", "test_solution_py"]}}
TOOL_S = copy.deepcopy(TOOL_A)
TOOL_S["input_schema"]["properties"]["assumptions"] = {"type": "array", "items": {"type": "string"},
    "description": "Every assumption you made where the requirements are ambiguous or incomplete"}
TOOL_S["input_schema"]["required"].append("assumptions")
TOOL_B = {"name": "write_tests", "description": "Write the pytest test suite.",
          "input_schema": {"type": "object", "properties": {
              "test_solution_py": {"type": "string", "description": "Full contents of the pytest test file; import from solution"}},
              "required": ["test_solution_py"]}}

LABEL_TOOL = {"name": "label_assertions", "input_schema": {"type": "object", "properties": {"assertions": {"type": "array", "items": {"type": "object", "properties": {
    "test": {"type": "string", "description": "test function name"},
    "assertion": {"type": "string", "description": "the assert statement or pytest.raises check, verbatim"},
    "label": {"type": "string", "enum": ["anchored", "contradicts", "unanchored"]},
    "req_ids": {"type": "array", "items": {"type": "string"}},
    "rationale": {"type": "string"}}, "required": ["test", "assertion", "label", "req_ids", "rationale"]}}}, "required": ["assertions"]}}
LABEL_PROMPT = """You are annotating a test suite for a requirements-engineering study. You see ONLY the requirements and the tests (not the implementation).
For EVERY assertion (each `assert` statement and each `pytest.raises` check; for parametrized tests, each parameter case counts as one assertion) give:
- label "anchored": the checked behaviour and expected value follow from one or more requirements and are consistent with them;
- label "contradicts": the expected value or behaviour contradicts what the requirements say;
- label "unanchored": the requirements do not determine this behaviour (e.g. inputs or outputs they do not discuss); the test encodes an extra assumption.
Give the requirement ids involved (empty for unanchored) and a one-sentence rationale. Compute expected values yourself from the requirements before deciding.

REQUIREMENTS
{req}

TESTS
```python
{tests}
```"""
SURFACE_TOOL = {"name": "map", "input_schema": {"type": "object", "properties": {"gaps": {"type": "array", "items": {"type": "object", "properties": {
    "gap": {"type": "string"}, "surfaced": {"type": "boolean"}, "evidence": {"type": "string"}}, "required": ["gap", "surfaced", "evidence"]}}}, "required": ["gaps"]}}
SURFACE_PROMPT = ("For each requirement gap below, decide whether the developer's list of assumptions explicitly addresses that specific ambiguity "
                  "(states a decision on it). Quote the matching assumption as evidence, or '' if none.\n\nGAPS:\n{gaps}\n\nASSUMPTIONS:\n{assumptions}")

def task_file(task, name): return open(os.path.join(BASE, "tasks", task, name)).read()

def _json(x):
    """Tool inputs occasionally arrive with nested fields serialised as JSON strings."""
    for _ in range(3):
        if isinstance(x, str):
            try: x = json.loads(x)
            except Exception: return x
    return x

# ---------------- generation ----------------
def agent_loops(runs, call_batch, max_rounds=H.MAX_ROUNDS, what="both files"):
    """runs: list of dicts with model, prompt, tool. Adds 'hist' (one entry per round)."""
    for r in runs:
        r["hist"], r["done"] = [], False
        r["msgs"] = [{"role": "user", "content": r["prompt"]}]
    for rnd in range(1, max_rounds + 1):
        act = [r for r in runs if not r["done"]]
        if not act: break
        outs = call_batch([{"model": r["model"], "system": SYSTEM, "messages": r["msgs"], "tool": r["tool"], "max_tokens": 8000} for r in act])
        for r, inp in zip(act, outs):
            if not isinstance(inp, dict) or "error" in inp or "solution_py" not in inp:
                r["hist"].append({"round": rnd, "error": str(inp)[:500]}); r["done"] = True; continue
            if "assumptions" in inp: inp["assumptions"] = _json(inp["assumptions"])
            res, _, out = H.run_suite(inp["solution_py"], inp["test_solution_py"])
            r["hist"].append({"round": rnd, "code": inp["solution_py"], "tests": inp["test_solution_py"],
                              "assumptions": inp.get("assumptions"), "passed": sum(res.values()), "total": len(res)})
            if res and all(res.values()): r["done"] = True; continue
            r["msgs"] += [{"role": "assistant", "content": [{"type": "tool_use", "id": f"t{rnd}", "name": r["tool"]["name"], "input": inp}]},
                          {"role": "user", "content": [{"type": "tool_result", "tool_use_id": f"t{rnd}", "content": FEEDBACK.format(out=out, what=what)}]}]
    for r in runs: r.pop("msgs", None); r.pop("done", None)
    return runs

def spec_first(items, call_batch):
    """items: list of dicts with model, req. Adds 'tests'."""
    outs = call_batch([{"model": i["model"], "system": SYSTEM, "messages": [{"role": "user", "content": PROMPT_B.format(req=i["req"])}],
                        "tool": TOOL_B, "max_tokens": 8000} for i in items])
    for i, o in zip(items, outs):
        i["tests"] = o.get("test_solution_py") if isinstance(o, dict) else None
    return items

# ---------------- evaluation ----------------
def probe_results(task, code):
    """Per-requirement intent-probe outcome on `code`: {req: all probes tagged req pass}."""
    acc = task_file(task, "test_acceptance.py"); res, _, _ = H.run_suite(code, acc)
    per = {}
    for n, src in H.test_functions(acc).items():
        req = re.search(r'req\("(R\d)"\)', src).group(1)
        per.setdefault(req, []).append(res.get(n, False))
    return {k: all(v) for k, v in per.items()}, sum(res.values()), len(H.test_functions(acc))

def evaluate(task, code, tests):
    ref = task_file(task, "reference.py")
    per_req, acc_pass, acc_total = probe_results(task, code)
    onC, cov, _ = H.run_suite(code, tests, cov=True)
    onR, _, _ = H.run_suite(ref, tests)
    cat = {}
    for n in H.test_functions(tests):
        cs = [v for k, v in onC.items() if k == n or k.startswith(n + "[")]
        rs = [v for k, v in onR.items() if k == n or k.startswith(n + "[")]
        c, r = (all(cs) if cs else False), (all(rs) if rs else False)
        cat[n] = {(True, True): "consistent", (True, False): "drift_candidate", (False, True): "detects_defect", (False, False): "broken"}[(c, r)]
    ms, nm = H.mutation_score(code, tests)
    return {"per_req": per_req, "code_violations": sorted(k for k, v in per_req.items() if not v), "acc_pass": acc_pass, "acc_total": acc_total,
            "n_tests": len(cat), "cat": cat, "cov": cov, "mut": ms, "n_mut": nm}

def label_requests(req, tests, model):
    return {"model": model, "system": None, "messages": [{"role": "user", "content": LABEL_PROMPT.format(req=req, tests=tests)}],
            "tool": LABEL_TOOL, "max_tokens": 32000}

def surface_request(task, assumptions, model):
    gaps = "\n".join(f"{g}: {d}" for g, d in GAPS[task].items())
    a = "\n".join(f"- {x}" for x in (assumptions or []))
    return {"model": model, "system": None, "messages": [{"role": "user", "content": SURFACE_PROMPT.format(gaps=gaps, assumptions=a)}],
            "tool": SURFACE_TOOL, "max_tokens": 4000}

def parse_list(o, key):
    """Unwrap {key: [...]} even when the list is nested or serialised more than once."""
    x = _json(o)
    for _ in range(4):
        if isinstance(x, dict) and key in x: x = _json(x[key])
        else: break
    if isinstance(x, list): return [_json(e) for e in x]
    return None
