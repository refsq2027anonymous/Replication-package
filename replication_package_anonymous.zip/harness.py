
"""Pilot harness: requirements fidelity of agent-generated tests.
The agent is a pluggable callable: llm(messages, tool) -> dict(tool input)."""
import ast, os, re, json, shutil, subprocess, sys, tempfile, copy
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor

CONFTEST = open(os.path.join(os.path.dirname(__file__), "tasks/T1_shipping/conftest.py")).read()
MAX_ROUNDS = 4
# Absolute path of the interpreter running the harness; tests run in a temp dir,
# so a bare "python" or a relative sys.executable would resolve to the wrong interpreter.
PY = os.path.abspath(sys.executable)

# ---------- running tests ----------
def run_suite(code, tests, timeout=20, cov=False):
    """Run pytest; return {test_name: passed(bool)} plus optional coverage."""
    d = tempfile.mkdtemp(prefix="run_")
    try:
        open(f"{d}/solution.py","w").write(code)
        open(f"{d}/test_suite.py","w").write(tests)
        open(f"{d}/conftest.py","w").write(CONFTEST)
        cmd = [PY,"-m","pytest","-q","-p","no:cacheprovider","--junitxml=r.xml","test_suite.py"]
        if cov: cmd = [PY,"-m","coverage","run","--branch","--include=solution.py","-m"] + cmd[1:]
        try:
            p = subprocess.run(cmd, cwd=d, capture_output=True, text=True, timeout=timeout)
            out = p.stdout[-4000:]
        except subprocess.TimeoutExpired:
            return {"__timeout__": False}, None, "TIMEOUT"
        res = {}
        if os.path.exists(f"{d}/r.xml"):
            for tc in ET.parse(f"{d}/r.xml").getroot().iter("testcase"):
                bad = any(ch.tag in ("failure","error","skipped") for ch in tc)
                res[tc.get("name")] = not bad
        covd = None
        if cov:
            subprocess.run([PY,"-m","coverage","json","-o","c.json"], cwd=d, capture_output=True)
            if os.path.exists(f"{d}/c.json"):
                s = json.load(open(f"{d}/c.json"))["totals"]
                covd = {"line": s["percent_covered"] if s.get("num_branches") is None else
                        100*s["covered_lines"]/max(1,s["num_statements"]),
                        "branch": 100*s.get("covered_branches",0)/max(1,s.get("num_branches",0)) if s.get("num_branches") else None}
        return res, covd, out
    finally:
        shutil.rmtree(d, ignore_errors=True)

# ---------- mutation ----------
SWAP = {ast.Add: ast.Sub, ast.Sub: ast.Add, ast.Mult: ast.Div, ast.Div: ast.Mult,
        ast.Lt: ast.LtE, ast.LtE: ast.Lt, ast.Gt: ast.GtE, ast.GtE: ast.Gt,
        ast.Eq: ast.NotEq, ast.NotEq: ast.Eq, ast.And: ast.Or, ast.Or: ast.And,
        ast.In: ast.NotIn, ast.NotIn: ast.In}
def _sites(tree):
    s = []
    for n in ast.walk(tree):
        if isinstance(n, (ast.BinOp, ast.BoolOp)) and type(n.op) in SWAP: s.append(("op", n))
        elif isinstance(n, ast.Compare):
            for i, o in enumerate(n.ops):
                if type(o) in SWAP: s.append(("cmp%d" % i, n))
        elif isinstance(n, ast.Constant) and type(n.value) in (int, float) and not isinstance(n.value, bool):
            s.append(("const", n))
        elif isinstance(n, ast.UnaryOp) and isinstance(n.op, ast.Not): s.append(("not", n))
    return s
def mutants(code):
    base = ast.parse(code); out = []
    for k in range(len(_sites(base))):
        t = ast.parse(code); kind, n = _sites(t)[k]
        if kind == "op": n.op = SWAP[type(n.op)]()
        elif kind.startswith("cmp"): i = int(kind[3:]); n.ops[i] = SWAP[type(n.ops[i])]()
        elif kind == "const": n.value = n.value + 1
        elif kind == "not":
            # replace `not x` by `x` via parent rewrite trick
            n.op = ast.UAdd()
        try:
            m = ast.unparse(ast.fix_missing_locations(t))
            if m != ast.unparse(base): out.append((f"{kind}@{getattr(n,'lineno','?')}", m))
        except Exception: pass
    return out
def mutation_score(code, tests, workers=12):
    ms = mutants(code)
    if not ms: return None, 0
    def kill(m):
        r, _, _ = run_suite(m[1], tests, timeout=10)
        return (not r) or (not all(r.values()))
    with ThreadPoolExecutor(workers) as ex: k = list(ex.map(kill, ms))
    return 100*sum(k)/len(ms), len(ms)

# ---------- test-function extraction ----------
def test_functions(tests):
    try: t = ast.parse(tests)
    except SyntaxError: return {}
    lines = tests.splitlines(); out = {}
    for n in ast.walk(t):
        if isinstance(n, ast.FunctionDef) and n.name.startswith("test"):
            out[n.name] = "\n".join(lines[n.lineno-1-len(n.decorator_list):n.end_lineno])
    return out
