import pytest
from solution import late_fee as f
@pytest.mark.req("R1")
def test_r1_neg():
    with pytest.raises(ValueError): f(-1, "book", "regular")
@pytest.mark.req("R1")
def test_r1_type():
    with pytest.raises(ValueError): f(1, "cd", "regular")
@pytest.mark.req("R1")
def test_r1_member():
    with pytest.raises(ValueError): f(1, "book", "staff")
@pytest.mark.req("R2")
def test_r2_dvd(): assert f(3, "dvd", "regular") == 3.00
@pytest.mark.req("R3")
def test_r3_grace(): assert f(2, "book", "regular") == 0.0
@pytest.mark.req("R3")
def test_r3_after_grace(): assert f(3, "book", "regular") == 0.25
@pytest.mark.req("R4")
def test_r4_book_cap(): assert f(100, "book", "regular") == 10.00
@pytest.mark.req("R4")
def test_r4_dvd_cap(): assert f(40, "dvd", "regular") == 25.00
@pytest.mark.req("R5")
def test_r5_senior_after_cap(): assert f(40, "dvd", "senior") == 12.50
@pytest.mark.req("R5")
def test_r5_student(): assert f(10, "dvd", "student") == 10.00

@pytest.mark.req("R6")
def test_r6_half_cent_rounds_up(): assert f(3, "book", "senior") == 0.13
@pytest.mark.req("R6")
def test_r6_half_cent_rounds_up_2(): assert f(7, "book", "senior") == 0.63
