# Library late fee
Implement `late_fee(days_late: int, item_type: str, member_type: str) -> float`.
`item_type` is "book" or "dvd"; `member_type` is "regular", "student" or "senior".

- R1: Negative `days_late`, or an unknown item or member type, raises `ValueError`.
- R2: Books cost 0.25 per late day; DVDs cost 1.00 per late day.
- R3: Books have a grace period: the first 2 late days are free (3 days late -> 1 chargeable day). DVDs have no grace period.
- R4: The fee is capped at 10.00 for books and 25.00 for DVDs.
- R5: Seniors pay 50% of the fee; the discount is applied after the cap. Students pay the regular fee.
- R6: The result is rounded to 2 decimals.
