from decimal import Decimal, ROUND_HALF_UP
def _r2(x):
    """Round to 2 decimals, halves rounded up (commercial rounding)."""
    return float(Decimal(str(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))
def late_fee(days_late, item_type, member_type):
    if days_late < 0 or item_type not in ("book","dvd") or member_type not in ("regular","student","senior"):
        raise ValueError("invalid")
    if item_type == "book":
        fee = min(max(days_late-2,0)*0.25, 10.00)
    else:
        fee = min(days_late*1.00, 25.00)
    if member_type == "senior": fee *= 0.5
    return _r2(fee)
