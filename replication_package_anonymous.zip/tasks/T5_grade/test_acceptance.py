import pytest
from solution import final_grade as f
@pytest.mark.req("R1")
def test_r1(): assert f(None, [10]) == "NA"
@pytest.mark.req("R2")
def test_r2_drop(): assert f(10, [0, 10, 10, 10]) == 10
@pytest.mark.req("R2")
def test_r2_no_drop_three(): assert f(10, [4, 10, 10]) == 9
@pytest.mark.req("R2")
def test_r2_empty(): assert f(10, []) == 6
@pytest.mark.req("R3")
def test_r3(): assert f(15, [10]) == 13
@pytest.mark.req("R4")
def test_r4_cap(): assert f(7, [20, 20]) == 9
@pytest.mark.req("R4")
def test_r4_boundary(): assert f(8, [20, 20]) == 13
@pytest.mark.req("R5")
def test_r5_half_up(): assert f(12.5, [15]) == 14
@pytest.mark.req("R5")
def test_r5_half_up_even(): assert f(15, [8.75]) == 13
@pytest.mark.req("R6")
def test_r6():
    with pytest.raises(ValueError): f(21, [10])
