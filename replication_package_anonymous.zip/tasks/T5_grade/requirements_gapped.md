# Course grade
Implement `final_grade(exam, assignments: list[float])` returning an int or the string "NA". All scores are on a 0-20 scale.

- R1: If `exam` is None (student absent), return "NA".
- R2: If there are 4 or more assignments, the lowest assignment score is dropped before averaging. An empty assignment list counts as an assignment average of 0.
- R3: The weighted score is 60% exam plus 40% assignment average.
- R4: If the exam score is insufficient, the final grade cannot exceed 9.
- R5: The final grade is the weighted score rounded to an integer.
- R6: Scores outside 0-20 raise `ValueError`.
