import math
def final_grade(exam, assignments):
    if exam is None: return "NA"
    if not (0 <= exam <= 20) or any(not (0 <= a <= 20) for a in assignments): raise ValueError("invalid")
    a = sorted(assignments)
    if len(a) >= 4: a = a[1:]
    avg = sum(a)/len(a) if a else 0.0
    w = 0.6*exam + 0.4*avg
    if exam < 8: w = min(w, 9)
    return int(math.floor(w + 0.5 + 1e-9))
