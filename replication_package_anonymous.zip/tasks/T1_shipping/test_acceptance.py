import pytest
from solution import shipping_fee as f
@pytest.mark.req("R1")
def test_r1_weight():
    with pytest.raises(ValueError): f(0, "BE", False, 10)
@pytest.mark.req("R1")
def test_r1_total():
    with pytest.raises(ValueError): f(1, "BE", False, -1)
@pytest.mark.req("R2")
def test_r2_1kg(): assert f(1.0, "BE", False, 10) == 4.95
@pytest.mark.req("R2")
def test_r2_5kg(): assert f(5.0, "BE", False, 10) == 7.95
@pytest.mark.req("R2")
def test_r2_started_kg(): assert f(5.2, "BE", False, 10) == 8.95
@pytest.mark.req("R2")
def test_r2_7kg(): assert f(7.0, "BE", False, 10) == 9.95
@pytest.mark.req("R3")
def test_r3_intl(): assert f(2, "NL", False, 10) == 15.90
@pytest.mark.req("R4")
def test_r4_express(): assert f(2, "BE", True, 10) == 17.95
@pytest.mark.req("R4")
def test_r4_express_intl():
    with pytest.raises(ValueError): f(2, "NL", True, 10)
@pytest.mark.req("R5")
def test_r5_free_boundary(): assert f(3, "BE", False, 50.0) == 0.0
@pytest.mark.req("R5")
def test_r5_no_free_express(): assert f(3, "BE", True, 80) == 17.95
@pytest.mark.req("R5")
def test_r5_no_free_intl(): assert f(3, "DE", False, 80) == 15.90

@pytest.mark.req("R6")
def test_r6_two_decimals(): assert f(0.5, "NL", False, 10) == 9.9
