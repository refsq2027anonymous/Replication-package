
def pytest_configure(config):
    config.addinivalue_line("markers", "req(id): requirement id")
