# Shipping fee calculator
Implement `shipping_fee(weight_kg: float, country: str, express: bool, order_total: float) -> float`.
Domestic means `country == "BE"`; any other country code is international.

- R1: If `weight_kg <= 0` or `order_total < 0`, raise `ValueError`.
- R2: The base fee depends on weight: up to and including 1 kg costs 4.95; above 1 kg up to and including 5 kg costs 7.95; above 5 kg costs 7.95 plus 1.00 per kilogram above 5 kg.
- R3: For international shipments the base fee is doubled.
- R4: Express delivery adds a surcharge of 10.00. Express delivery is only available domestically; requesting express for an international shipment raises `ValueError`.
- R5: Orders over 50.00 ship for free.
- R6: The result is rounded to 2 decimals.
