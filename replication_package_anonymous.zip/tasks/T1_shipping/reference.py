from decimal import Decimal, ROUND_HALF_UP
def _r2(x):
    """Round to 2 decimals, halves rounded up (commercial rounding)."""
    return float(Decimal(str(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))
import math
def shipping_fee(weight_kg, country, express, order_total):
    if weight_kg <= 0 or order_total < 0: raise ValueError("invalid")
    dom = country == "BE"
    if express and not dom: raise ValueError("express domestic only")
    if dom and not express and order_total >= 50: return 0.0
    if weight_kg <= 1: base = 4.95
    elif weight_kg <= 5: base = 7.95
    else: base = 7.95 + math.ceil(weight_kg - 5) * 1.00
    if not dom: base *= 2
    if express: base += 10.00
    return _r2(base)
