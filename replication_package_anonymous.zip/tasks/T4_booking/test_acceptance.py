import pytest
from solution import can_book as f
@pytest.mark.req("R1")
def test_r1():
    with pytest.raises(ValueError): f([], 600, 600)
@pytest.mark.req("R2")
def test_r2_early(): assert f([], 465, 540) is False
@pytest.mark.req("R2")
def test_r2_closing_edge(): assert f([], 1140, 1200) is True
@pytest.mark.req("R3")
def test_r3(): assert f([], 610, 660) is False
@pytest.mark.req("R4")
def test_r4_exact(): assert f([], 480, 720) is True
@pytest.mark.req("R4")
def test_r4_over(): assert f([], 480, 735) is False
@pytest.mark.req("R5")
def test_r5_overlap(): assert f([(600, 660)], 645, 705) is False
@pytest.mark.req("R5")
def test_r5_back_to_back(): assert f([(600, 660)], 660, 720) is True
@pytest.mark.req("R5")
def test_r5_back_to_back_before(): assert f([(600, 660)], 540, 600) is True
@pytest.mark.req("R5")
def test_r5_contains(): assert f([(600, 615)], 540, 720) is False

@pytest.mark.req("R6")
def test_r6_all_rules_satisfied(): assert f([(480, 540)], 600, 660) is True
