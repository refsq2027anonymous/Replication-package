def can_book(existing, start, end):
    if start >= end: raise ValueError("invalid")
    if start < 480 or end > 1200: return False
    if start % 15 or end % 15: return False
    if end - start > 240: return False
    for s, e in existing:
        if start < e and s < end: return False
    return True
