# Meeting room booking
Implement `can_book(existing: list[tuple[int, int]], start: int, end: int) -> bool`.
Times are minutes since midnight; each booking is a pair (start, end).

- R1: If `start >= end`, raise `ValueError`.
- R2: A booking must lie within opening hours 08:00-20:00: start >= 480 and end <= 1200. Otherwise return False.
- R3: Start and end must both be on a 15-minute boundary (multiple of 15). Otherwise return False.
- R4: A booking may last at most 4 hours (240 minutes). Longer bookings return False.
- R5: A booking must not overlap any existing booking.
- R6: Return True if all rules are satisfied.
