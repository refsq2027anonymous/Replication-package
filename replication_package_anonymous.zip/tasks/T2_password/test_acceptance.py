import pytest
from solution import check_password as f
@pytest.mark.req("R1")
def test_r1_11(): assert "LENGTH" in f("Abcdefghi1!", "zz")
@pytest.mark.req("R1")
def test_r1_12(): assert "LENGTH" not in f("Abcdefghij1!", "zz")
@pytest.mark.req("R2")
def test_r2_two_classes(): assert "CLASSES" in f("abcdefghijk1", "zz")
@pytest.mark.req("R2")
def test_r2_three_classes(): assert f("abcdefghij1!", "zz") == []
@pytest.mark.req("R3")
def test_r3_case_insensitive(): assert "USERNAME" in f("xxBOBxx1234!a", "bob")
@pytest.mark.req("R3")
def test_r3_short_username(): assert "USERNAME" not in f("xxboxx1234!Aa", "bo")
@pytest.mark.req("R4")
def test_r4_three(): assert "REPEAT" in f("Abcdeffff12!x", "zz")
@pytest.mark.req("R4")
def test_r4_two_ok(): assert "REPEAT" not in f("Abcdeff12!xyz", "zz")
@pytest.mark.req("R5")
def test_r5_all_in_order(): assert f("bobaaa", "bob") == ["LENGTH", "CLASSES", "USERNAME", "REPEAT"]
