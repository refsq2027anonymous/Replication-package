# Password policy checker
Implement `check_password(password: str, username: str) -> list[str]` returning the codes of all violated rules, in the order listed below (empty list if the password is acceptable).

- R1: "LENGTH" if the password has fewer than 12 characters.
- R2: "CLASSES" if the password contains characters from fewer than 3 of these 4 classes: lowercase letters, uppercase letters, digits, other characters.
- R3: "USERNAME" if the username occurs in the password, compared case-insensitively. This rule is only checked when the username has at least 3 characters.
- R4: "REPEAT" if the password contains the same character more than twice in a row (e.g. "aaa").
- R5: All applicable codes are reported, not just the first one.
