def check_password(password, username):
    v=[]
    if len(password) < 12: v.append("LENGTH")
    cl = sum([any(c.islower() for c in password), any(c.isupper() for c in password),
              any(c.isdigit() for c in password), any(not c.isalnum() for c in password)])
    if cl < 3: v.append("CLASSES")
    if len(username) >= 3 and username.lower() in password.lower(): v.append("USERNAME")
    if any(password[i]==password[i+1]==password[i+2] for i in range(len(password)-2)): v.append("REPEAT")
    return v
